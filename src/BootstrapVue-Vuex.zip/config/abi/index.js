'use strict';

module.exports = {
    ERC20: require('./ERC20ABI'),
    ERC721: require('./ERC721ABI')
};
