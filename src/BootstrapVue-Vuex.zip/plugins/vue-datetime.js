import Vue from 'vue';
import { Datetime } from 'vue-datetime';
import 'vue-datetime/dist/vue-datetime.css';

Vue.component('datetime', Datetime);
Vue.use(Datetime);
