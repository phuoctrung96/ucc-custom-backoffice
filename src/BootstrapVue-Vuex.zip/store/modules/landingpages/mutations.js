export default {
    SET_LANDING_PAGES(state, data) {
        state.pages = data;
    }
};
