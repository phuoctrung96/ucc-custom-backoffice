export default {
    loyaltyPrograms: state => state.loyaltyPrograms,
    loyaltyProgramsPagination: state => state.loyaltyProgramsPagination,
    loyaltyProgram: state => state.loyaltyProgram,
    loyaltyProgramLevels: state => state.loyaltyProgramLevels,
    loyaltyProgramMembers: state => state.loyaltyProgramMembers,
    loyaltyProgramMembersPagination: state =>
        state.loyaltyProgramMembersPagination
};
