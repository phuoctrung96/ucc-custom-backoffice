export default {
    SET_IS_ADMIN(state, payload) {
        state.isAdmin = payload;
    }
};
