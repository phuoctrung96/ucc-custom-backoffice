export default {
    isAdmin: state => state.isAdmin
};
