export default {
    getAllPersonas: state => state.personas
};
