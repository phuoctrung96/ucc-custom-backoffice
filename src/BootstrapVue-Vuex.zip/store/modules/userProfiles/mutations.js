export default {
    SET_PERSONAS(state, data) {
        state.personas = data;
    }
};
