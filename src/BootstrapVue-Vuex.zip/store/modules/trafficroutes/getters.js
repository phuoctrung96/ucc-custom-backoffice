export default {
    getAllTrafficRoutes: state => state.allTrafficRoutes,
    getTrafficRouteById: state => state.trafficRoute,
    getTotalDestinationPercent: state => state.totalDestinationPercent
};
