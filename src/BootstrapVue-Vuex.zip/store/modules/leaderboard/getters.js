export default {
  getAllLeaderboards: state => state.allLeaderboards,
  getLeaderboardById: state => state.leaderboard
};
