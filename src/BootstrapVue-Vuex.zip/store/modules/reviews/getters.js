export default {
    reviewFolders: state => state.folders,
    selectedReviewFolder: state => state.selectedFolder,
    reviewList: state => state.reviewList,
    reviewCompleting: state => state.isCompleting,
    iconSets: state => state.iconSets
};
