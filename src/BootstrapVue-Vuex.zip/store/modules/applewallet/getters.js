export default {
  getAllPassTemplates: state => state.allPassTemplates,
  getSinglePassTemplate: state => state.singlePassTemplate
};
