export default {
    pageList: state => state.pages,
    templateList: state => state.templates,
    emailTemplates: state => state.emailTemplates
};
