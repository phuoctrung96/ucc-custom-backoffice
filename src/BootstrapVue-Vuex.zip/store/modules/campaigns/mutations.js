export default {
    SET_CAMPAIGNS(state, data) {
        state.campaigns = data;
    }
};
