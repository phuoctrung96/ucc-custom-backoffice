export default {
    SET_PROGRAMS_STATS(state, data) {
        state.programs = data;
    },

    SET_SURVEYS_STATS(state, data) {
        state.surveys = data;
    },

    SET_QUIZZES_STATS(state, data) {
        state.quizzes = data;
    }
};
