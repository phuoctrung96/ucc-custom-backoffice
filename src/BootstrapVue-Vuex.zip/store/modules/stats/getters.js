export default {
    programsStats: state => state.programs,
    surveysStats: state => state.surveys,
    quizzesStats: state => state.quizzes
};
