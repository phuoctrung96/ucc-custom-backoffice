export default {
    getPointsRequestBody: state => state.addClassRequestBody,
};
