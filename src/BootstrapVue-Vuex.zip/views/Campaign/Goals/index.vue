<template>
    <div class="content with-sidebar">
        1
    </div>
</template>
