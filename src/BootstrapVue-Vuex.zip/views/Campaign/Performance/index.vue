<template>
    <div class="content">
        <h3 class="page-header">
            Campaigns
        </h3>
    </div>
</template>
