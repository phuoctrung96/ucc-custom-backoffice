<template>
    <div class="content">
        <h3 class="page-header">
            Please select a review folder or create a new one
        </h3>
    </div>
</template>

<script>
export default {
    name: 'reviews-page',
    components: {}
    // created() {
    //     if (this.$store.getters['reviewFolders'].length === 0) {
    //         this.$store.dispatch('getAllReviewFolders');
    //     }
    // }
};
</script>
