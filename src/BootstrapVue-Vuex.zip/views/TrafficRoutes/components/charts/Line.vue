<script>
import { Line } from 'vue-chartjs';

export default {
    extends: Line,
    props: {
        data: { type: Object, required: true, default: null },
        options: { type: Object, required: false, default: null }
    },
    mounted() {
        this.renderChart(this.data, this.options);
    }
};
</script>
