<template>
    <div class="content">
        <h3 class="page-header">
            Lottery page
        </h3>
    </div>
</template>

<script>
export default {
    name: 'lottery-page',
    components: {}
};
</script>
