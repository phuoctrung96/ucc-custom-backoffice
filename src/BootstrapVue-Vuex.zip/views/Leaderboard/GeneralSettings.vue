<template>
    <div class="content">
        <div class="py-4">
            <h4 class="text-brand">General</h4>
        </div>
    </div>
</template>

<script>
export default {
    name: 'general-settings-page',
    data: () => ({})
};
</script>
