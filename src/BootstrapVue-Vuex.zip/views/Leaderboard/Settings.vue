<template>
    <div class="content">
        <div class="py-4">
            <h4 class="text-brand">Leaderboard Settings</h4>
        </div>
    </div>
</template>

<script>
export default {
    name: 'leaderboard-settings-page',
    data: () => ({})
};
</script>
