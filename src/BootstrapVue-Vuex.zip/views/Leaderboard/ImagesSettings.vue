<template>
    <div class="content">
        <div class="py-4">
            <h4 class="text-brand">Images</h4>
        </div>
    </div>
</template>

<script>
export default {
    name: 'images-settings-page',
    data: () => ({})
};
</script>