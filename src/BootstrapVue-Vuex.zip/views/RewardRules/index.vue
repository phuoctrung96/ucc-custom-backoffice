<template>
    <div class="content">
        <div class="py-4">
            <h4 class="text-brand">Reward Rules</h4>
        </div>
    </div>
</template>

<script>
export default {
    name: 'reward-rules-page',
    data: () => ({})
};
</script>
