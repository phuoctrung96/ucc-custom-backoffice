<template>
    <div class="content">
        <div class="py-4">
            <h4 class="text-brand">Template Settings</h4>
        </div>
    </div>
</template>

<script>
export default {
    name: 'template-settings-page',
    data: () => ({})
};
</script>
<style lang="scss" scoped>
h4 {
        font-size: 28px;
        line-height: 40px;
    }
</style>
