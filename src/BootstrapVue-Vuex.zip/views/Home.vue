<template>
    <div class="content">
        Home page
    </div>
</template>

<script>
export default {
    name: 'home',
    components: {}
};
</script>
