/* ============
 * Italian Language File
 * ============
 */

export default {
    CONTENT: require('./content'),
    NOTIFY: require('./notify'),
    SURVEY: require('./survey'),
    QUIZ: require('./quiz')
};
